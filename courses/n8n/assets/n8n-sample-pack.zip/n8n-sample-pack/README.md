# n8n Lite Pack 演練素材包

對應 14 個 workflow 的測試素材。把對應子資料夾的內容**複製**到你的 starter-kit 內（**不要動原本的 shared 資料夾結構**）：

## 使用方法

1. 解壓本 zip 到任意地方
2. 把各子資料夾內的檔**複製**到 `n8n-starter-kit/shared/<對應資料夾>/`
3. 開 n8n UI → 對應 workflow → Execute

## 對照表

| 子資料夾 | 對應 workflow | 用途 |
|---|---|---|
| `pdf-inbox/` | #02 PDF AI 改名 | 3 個檔名無意義 PDF（合約 / 報價單 / 教材內容）測試 AI 改名 |
| `batch-inbox/` | #03 批次錯誤恢復 | 4 個正常 + 1 個損壞檔（corrupted.bin）測試錯誤路徑 |
| `daily-input/` | #04 定時 AI 日報 | .md + .txt 混合測試多格式摘要 |
| `client-inbox/` | #10 客戶資料夾整理 | PDF/PPTX/DOCX/XLSX/PNG/MD mixed，覆蓋 6 個分類 |
| `leads-inbox/` | #11 CSV 線索清洗 | 30 筆雜亂線索（含重複/缺欄/格式不一）測試清洗評分 |
| `knowledge-docs/` | #12 本地知識庫 RAG | 4 份知識文件（公司 / FAQ / 退款 / 案例）測試 RAG 索引 |
| `ops-input/` | #13 ops snapshot | API gateway + DB metrics CSV（含異常 spike）測試告警 |

**不需要素材的 workflow**（webhook trigger / OAuth credential / 設定驅動）：
- #01 webhook hello world
- #05 Telegram 通知測試
- #06 Webhook → Gemini → 本機檔（POST 觸發）
- #07 Quick Tunnel receiver
- #08 Expression 練習
- #09 Gmail 分類（需 OAuth）
- #14 API monitor（在 workflow 內設定 API list）

## 重新產生

如果想客製或補檔，跑這個腳本：

```bash
pip install reportlab python-docx python-pptx openpyxl pillow
python3 build_sample_pack.py
```
